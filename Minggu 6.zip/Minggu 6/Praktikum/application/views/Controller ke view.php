<html>
<head><title>Controller dan View lebih dari 1 variabel</title></head>
<body>
	<h2>Menggirim Data dari Controller ke View</h2>

	<!--memanggil variabel 1-->
	variabel1 : <?php echo variabel1; ?></br>

	<!--memanggil variabel 2-->
	variabel2 : <?php echo variabel2; ?></br>	
</body>
</html>